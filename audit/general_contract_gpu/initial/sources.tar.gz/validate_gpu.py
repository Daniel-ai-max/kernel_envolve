"""Bounded broad-contract GPU controls; no model calls."""
import base64,gzip,hashlib,json,os,pathlib,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
REPORT={'scope':'Broad public task/validator controls and acceptance costs; no agent search, no hidden final tests','model_calls':0}
def emit():
 data=json.dumps(REPORT).encode();(ROOT/'validation.json').write_bytes(data)
 blob=base64.b64encode(gzip.compress(data)).decode()
 for i in range(0,len(blob),28000):
  print('KE_REPORT_PART '+json.dumps({'index':i//28000,'total':(len(blob)+27999)//28000,'sha256':hashlib.sha256(blob.encode()).hexdigest(),'data':blob[i:i+28000]}),flush=True)
def main():
 import torch,triton,numpy
 from kernel_envolve.storage import evaluator_hash
 from kernel_envolve.cli import evaluate
 assert torch.cuda.device_count()==1
 REPORT['environment']={'gpu':torch.cuda.get_device_name(0),'capability':torch.cuda.get_device_capability(0),'torch':torch.__version__,'triton':triton.__version__,'numpy':numpy.__version__,'cuda':torch.version.cuda,'evaluator_hash':evaluator_hash()}
 print('KE_ENV '+json.dumps(REPORT['environment']),flush=True)
 start=time.perf_counter()
 proc=subprocess.run([sys.executable,'-m','pytest','-q'],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120,env=os.environ|{'KERNEL_ENVOLVE_TEST_CUDA':'1'})
 REPORT['tests']={'returncode':proc.returncode,'wall_seconds':time.perf_counter()-start,'output':proc.stdout};print(proc.stdout,flush=True)
 assert proc.returncode==0,'GPU tests failed'
 sys.path.insert(0,str(ROOT/'audit'))
 import probe_general_tasks
 REPORT['controls']=probe_general_tasks.run(ROOT/'controls','cuda:0',True)
 assert REPORT['controls']['completed']
 REPORT['full_costs']=[]
 for name in ['row_sum','matmul','fused_relu']:
  task=ROOT/'controls/development'/name
  start=time.perf_counter();_,r=evaluate(task,'full',timeout=150)
  REPORT['full_costs'].append({'task':name,'api_wall_seconds':time.perf_counter()-start,'result':r})
  print('KE_FULL '+json.dumps({'task':name,'seconds':REPORT['full_costs'][-1]['api_wall_seconds'],'correctness':r.get('correctness'),'error':r.get('error'),'eligible':r.get('decision',{}).get('eligible_for_best')}),flush=True)
  assert r['correctness']=='pass',r.get('error')
 REPORT['completed']=True
if __name__=='__main__':
 try:main()
 except BaseException as exc:
  REPORT['controller_error']={'type':type(exc).__name__,'message':str(exc)}
  raw=ROOT/'controls/raw.json.gz'
  if raw.exists():REPORT['controls']=json.loads(gzip.decompress(raw.read_bytes()))
  raise
 finally:emit()
 print('KE_VALIDATION_DONE',flush=True)
