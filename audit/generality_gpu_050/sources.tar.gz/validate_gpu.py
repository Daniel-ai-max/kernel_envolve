"""One bounded GPU validation: frozen pilot sources, broader inputs, no model search."""
import base64, gzip, hashlib, json, os, pathlib, shutil, subprocess, sys, time
ROOT=pathlib.Path(__file__).resolve().parent
REPORT={'scope':'Frozen candidates on new shapes; extended layouts separately labelled; evaluator sampling costs. No workflow ranking.','records':[]}

def run(command, timeout=120, env=None):
    start=time.perf_counter()
    p=subprocess.run(command,cwd=ROOT,env=os.environ|(env or {}),text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
    return p,time.perf_counter()-start

def emit():
    (ROOT/'validation.json').write_text(json.dumps(REPORT,indent=2))
    blob=base64.b64encode(gzip.compress(json.dumps(REPORT).encode())).decode()
    for i in range(0,len(blob),28000):
        print('KE_REPORT_PART '+json.dumps({'index':i//28000,'total':(len(blob)+27999)//28000,'sha256':hashlib.sha256(blob.encode()).hexdigest(),'data':blob[i:i+28000]}),flush=True)

def cases_for(task):
    if task=='matmul':
        shapes=[(1,33,17,1),(15,31,33,1),(16,32,31,1),(17,33,32,2),(31,65,63,1),(33,63,65,3),(129,127,255,1),(257,129,127,2),(64,1025,33,1),(511,65,257,1)]
        return [{'id':f'm{m}-n{n}-k{k}-s{s}','args':{'device':'cuda:0','m':m,'n':n,'k':k,'stride':s},'weight':1}for m,n,k,s in shapes]
    shapes=[(1,1,1),(3,255,1),(3,256,1),(3,257,2),(17,1023,1),(17,1024,2),(17,1025,3),(33,8191,1),(33,8192,2),(33,8193,3),(9,32769,1)]
    return [{'id':f'r{r}-c{c}-s{s}','args':{'device':'cuda:0','rows':r,'columns':c,'stride':s},'weight':1}for r,c,s in shapes]

def make_suite(kind):
    base=ROOT/'suites'/kind;base.mkdir(parents=True)
    shutil.copy2(ROOT/'audit/search_final_acceptance.py',base/'verify.py')
    for task in ['row_sum','matmul','fused_relu']:
        src=ROOT/'audit/search_tasks'/task;dst=base/'search_tasks'/task;dst.mkdir(parents=True)
        cfg=json.loads((src/'task.json').read_text());cfg['cases']=cases_for(task)
        code=(src/'task.py').read_text()
        if kind=='extended_layout':
            cfg['cases']=cfg['cases'][3:5]
            if task=='matmul':
                code=code.replace('a = rand(case["m"], case["k"])','a = rand(case["m"], case["k"] + 7)[:, :case["k"]]')
            elif task=='fused_relu':
                code=code.replace('case["columns"] * case["stride"])','case["columns"] * case["stride"] + 7)')
                code=code.replace('[:, :: case["stride"]]','[:, :case["columns"] * case["stride"]:case["stride"]]')
            else:
                code=code.replace('case["columns"] * case["stride"])','case["columns"] * case["stride"] + 7)')
                code=code.replace('[:, :: case["stride"]]','[:, :case["columns"] * case["stride"]:case["stride"]]')
        (dst/'task.json').write_text(json.dumps(cfg));(dst/'task.py').write_text(code)
        shutil.copy2(src/'candidate.py',dst/'candidate.py')
    return base

def verify(suite,task,candidate,label,check_only=False):
    output=suite/(label+'.json')
    cmd=[sys.executable,str(suite/'verify.py'),'--task',task,'--candidate',str(candidate),'--seeds',str(ROOT/'seeds.json'),'--device','cuda:0','--output',str(output)]
    if check_only:cmd.append('--check-only')
    proc,elapsed=run(cmd,150)
    result=json.loads(output.read_text())if output.exists()else {'correct':False,'process_error':proc.stdout[-6000:]}
    row={'kind':suite.name,'task':task,'label':label,'check_only':check_only,'process_returncode':proc.returncode,'command_wall_seconds':elapsed,'result':result}
    REPORT['records'].append(row)
    print('KE_CASE '+json.dumps({k:v for k,v in row.items()if k!='result'}|{'correct':result.get('correct'),'error':result.get('error'),'gains':result.get('gain_by_batch')}),flush=True)
    return result

def cost_probe():
    from kernel_envolve.cli import evaluate
    task_code='''import torch

def make_inputs(case,seed):
 g=torch.Generator(device="cuda").manual_seed(seed)
 return tuple(torch.randn(case["n"]*case["stride"],device="cuda",generator=g)[::case["stride"]] for _ in range(2))
def reference(x,y): return x+y
baseline=reference
'''
    candidates='def run(x,y): return x+y\n'
    sizes=[255,256,257,1023,1024,1025,65535,65536,65537,1048575,1048576,1048577]
    costs=[]
    for repeat in range(3):
        for scope in (['all_timed','representative_timing']if repeat%2==0 else ['representative_timing','all_timed']):
            path=ROOT/'cost'/f'{repeat}-{scope}';path.mkdir(parents=True)
            cfg={'name':scope,'objective':'equal-weight measured cases; evaluator cost probe','device':'cuda:0','timer':'wall','full_trials':3,'warmup':1,'cases':[]}
            for i,n in enumerate(sizes):
                c={'id':str(n),'args':{'n':n,'stride':2 if i%2 else 1}}
                c.update({'weight':1}if scope=='all_timed' or i in (2,5,8,11)else{'measure':False,'quick':False})
                cfg['cases'].append(c)
            (path/'task.json').write_text(json.dumps(cfg));(path/'task.py').write_text(task_code);(path/'candidate.py').write_text(candidates)
            start=time.perf_counter();_,result=evaluate(path,'full',timeout=90);elapsed=time.perf_counter()-start
            assert result['correctness']=='pass',result.get('error')
            row={'repeat':repeat,'scope':scope,'api_wall_seconds':elapsed,'result':result}
            costs.append(row)
            print('KE_COST '+json.dumps({'repeat':repeat,'scope':scope,'api_wall_seconds':elapsed,'checks':len(result['checks']),'samples':len(result['samples'])}),flush=True)
    REPORT['costs']=costs

def main():
    import torch,triton,numpy
    from kernel_envolve.storage import evaluator_hash
    assert torch.cuda.device_count()==1
    REPORT['environment']={'gpu':torch.cuda.get_device_name(0),'capability':torch.cuda.get_device_capability(0),'torch':torch.__version__,'triton':triton.__version__,'numpy':numpy.__version__,'cuda':torch.version.cuda,'evaluator_hash':evaluator_hash()}
    print('KE_ENV '+json.dumps(REPORT['environment']),flush=True)
    proc,elapsed=run([sys.executable,'-m','pytest','-q'],120,{'KERNEL_ENVOLVE_TEST_CUDA':'1'})
    REPORT['tests']={'returncode':proc.returncode,'wall_seconds':elapsed,'output':proc.stdout};print(proc.stdout,flush=True)
    assert proc.returncode==0,'GPU tests failed'
    (ROOT/'seeds.json').write_text(json.dumps([1907101,1907107,1907117]))
    sources=[('matmul','03-matmul-kernel_envolve_skill'),('matmul','04-matmul-goal_only'),('fused_relu','08-fused_relu-kernel_envolve_skill')]
    for kind in ['new_shapes','extended_layout']:
        suite=make_suite(kind)
        for task in ['row_sum','matmul','fused_relu']:
            control=verify(suite,task,suite/'search_tasks'/task/'candidate.py','control-'+task,True)
            assert control['correct'],'Correct baseline control failed'
        for task,trial in sources:
            candidate=ROOT/'audit/search_pilot_20261110/trials'/trial/'submission.py.txt'
            verify(suite,task,candidate,trial)
    cost_probe();REPORT['completed']=True
if __name__=='__main__':
    try:main()
    except BaseException as exc:
        REPORT['controller_error']={'type':type(exc).__name__,'message':str(exc)}
        raise
    finally:emit()
    print('KE_VALIDATION_DONE',flush=True)
